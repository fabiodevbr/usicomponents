import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-smart-select-text',
  templateUrl: './smart-select-text.component.html',
  styleUrls: ['./smart-select-text.component.scss']
})
export class SmartSelectTextComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
