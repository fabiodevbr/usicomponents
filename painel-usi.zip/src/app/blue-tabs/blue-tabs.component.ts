import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'blue-tabs',
  templateUrl: './blue-tabs.component.html',
  styleUrls: ['./blue-tabs.component.scss']
})
export class BlueTabsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
