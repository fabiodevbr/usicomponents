import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modal-excluir',
  templateUrl: './modal-excluir.component.html',
  styleUrls: ['./modal-excluir.component.scss']
})
export class ModalExcluirComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
